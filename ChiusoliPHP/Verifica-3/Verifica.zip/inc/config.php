<?php
$host = "localhost:10010";
$dbname = "adventureworks2019_2025";
$user = "root";
$pass = "root";
